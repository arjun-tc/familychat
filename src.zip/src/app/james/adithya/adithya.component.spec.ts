import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdithyaComponent } from './adithya.component';

describe('AdithyaComponent', () => {
  let component: AdithyaComponent;
  let fixture: ComponentFixture<AdithyaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdithyaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdithyaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
