import { Component, OnInit } from '@angular/core';
import { InteractionService } from '../../interaction.service';
@Component({
  selector: 'app-dilip',
  templateUrl: './dilip.component.html',
  styleUrls: ['./dilip.component.scss']
})
export class DilipComponent implements OnInit {

 
  constructor(private _interactionService: InteractionService) { }
  
  name = "Dilip";
  senderName = "";
  receiverName = "";
  question = "there is no message";
  data = this._interactionService.people;
  listOfNames = this.data.map(value => value.name);
  indexOfMine = 0;
  answer = "";
  message ="There is no new message";
  
  ngOnInit() {
    this._interactionService.Message$
      .subscribe(
        message => {
          this.question = message;
        }
      )
    this._interactionService.senderName$
      .subscribe(
        name2 => {
          this.senderName = name2;
        })
    this._interactionService.receiverName$
      .subscribe(
        name1 => {
          this.receiverName = name1;

          if (this.receiverName == this.name) {
            this.setAnswer();
            this.sendReply();
            
          }
          
        }
      )
      this._interactionService.senderName$
     .subscribe(
         name =>{
           this.senderName =name;
         }
     ) 

  }
  setAnswer(){
    this.indexOfMine = this.listOfNames.findIndex(value => value == this.name);
    if(Object.keys(this.data[this.indexOfMine].Ques).some(value => value == this.question)){
    this.answer = `${this.name}: ${this.data[this.indexOfMine].Ques[this.question]}`;
       
    }
    else{
      this.answer=`${this.name}: sorry I don't get you`;

    }
  }
  sendReply() {
    this.message = `Message From ${this.senderName}: ${this.question}`;   
    
    this._interactionService.sendReply(this.answer);
  }

}
