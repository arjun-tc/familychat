import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges, OnInit, SimpleChange, AfterViewInit } from '@angular/core';
import { InteractionService } from '../interaction.service';
@Component({
  selector: 'person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.scss']
})
export class PersonComponent implements OnInit {
  constructor(private _interactionService: InteractionService) { }
  @Input() public nameOfThePerson: string;
  @Input() public messageSendBySomeOne: string;
  messageForMe = "you did'nt messaged anyone ";
  messageFromMe: string;
  personToTalk = "";
  people = this._interactionService.people;
  listOfNames = this.people.map(value => value.name);
  listOfNamesToTalk =[];
  reply = "noreply";
  receiverName: string;
  ngOnInit() {
    this._interactionService.replyMessage$
      .subscribe(
        message => { this.reply = message; }
      )
    this._interactionService.senderName$
      .subscribe(
        name => {
          if (name == this.nameOfThePerson) {
            this.setMessage();
          }
        }
      )
      this.getListOfNamesToTalk();
  }
  getListOfNamesToTalk(){
    this.listOfNames.forEach(value => {
      if( value != this.nameOfThePerson)
          this.listOfNamesToTalk.push(value);
    })
  }
  setMessage() {
    if(this.reply == "noreply"){
      this.messageForMe ="some network issue";
    }
    else{
    this.messageForMe =`Reply from ${this.reply}`;}
  }
  getDataFromMe(updatedData: string) {
    this.messageFromMe = updatedData;
  }
  sendMessage() {
    console.log(this.personToTalk);

    if (this.listOfNames.some(value => value == this.personToTalk)) {
      this._interactionService.sendMessage(this.personToTalk, this.messageFromMe, this.nameOfThePerson);
    }
    else {
      alert("choose the person to talk");
    }
  }
}
